function calcular(){
    let n1 = Number(window.prompt("Digite um valor"));
    const raiz = Math.sqrt(n1);
    console.log(raiz);
    const raizCubica = Math.cbrt(n1);
    console.log(raizCubica);
    const parteInteira = parseInt(n1);
    console.log(parteInteira);
    const valorInteiro = Math.round(n1);
    console.log(valorInteiro);
    let mensagem = window.document.getElementById("mensagem");

    mensagem.innerHTML = `<p>O número escolhido foi <strong>${n1}</strong>.</p>
    <hr>
    <p>O seu valor absoluto é: ${n1}.</p>
    <p>A sua parte inteira é: ${parteInteira}.</p>
    <p>O valor inteiro mais próximo é: ${valorInteiro}.</p>
    <p>Sua raíz quadrada é: ${raiz}.</p>
    <p>Sua raíz cúbica é: ${raizCubica}.</p>
    <p>O valor de ${n1} ao quadrado é: ${n1*n1}.</p>
    <p>O valor de ${n1} ao cubo é: ${n1*(n1*n1)}.</p>`


}