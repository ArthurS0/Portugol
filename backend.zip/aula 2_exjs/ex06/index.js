function calcular(){
    let n1 = Number(window.prompt("Digite um valor"));
    let n2 = Number(window.prompt("Digite outro valor"));
    let mensagem = window.document.getElementById("mensagem");

    mensagem.innerHTML = `<p>A soma de ${n1} + ${n2} é ${n1+n2}.</p>`


}