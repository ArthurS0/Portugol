const express = require('express');
const router = express.Router();
const db = require('./connect/db');

router.post('/clientes', (req, res) => {
    const { nome, cpf, email, endereco, data_nascimento, data_cadastro } = req.body;
    const query = 'INSERT INTO clientes (nome, cpf, email, endereco, data_nascimento, data_cadastro) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(query, [nome, cpf, email, endereco, data_nascimento, data_cadastro], (err, results) => {
        if (err) return res.status(500).send(err);
        res.status(201).json({ id: results.insertId });
    });
});

router.get('/clientes', (req, res) => {
    db.query('SELECT * FROM clientes', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

module.exports = router;