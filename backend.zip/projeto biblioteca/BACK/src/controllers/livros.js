const con = require('../connect/connect').con;

const create = (req, res) => {
    let titulo = req.body.titulo;
    let autor = req.body.autor;
    let valor = req.body.valor;

    let query = `INSET INTO livros (titulo, autor, valor) VALUES`
    query += `('${titulo}', '${autor}', '${valor}');`;
    con.query(query, (err, result)=>{
        if(err){
            res.status(500).json(err)
        }else{
            res.status(201).json(result)
        }
    })

}