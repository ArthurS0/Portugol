const express = require('express')
const router = express.Router();

const livros = require('./controllers/livros')

router.post('/livros', livros.create);
router.get('/livros', livros.read);

module.exports = router;