function clicou1(){
    let mensagem = window.document.getElementById("mensagem");

    mensagem.innerHTML = `<p>
    Clicou no primeiro botão.</p>`
}

function clicou2(){
    let mensagem = window.document.getElementById("mensagem");

    mensagem.innerHTML = `<p>
    Clicou no segundo botão.</p>`
}

function clicou3(){
    let mensagem = window.document.getElementById("mensagem");

    mensagem.innerHTML = `<p>
    Clicou no terceiro botão.</p>`
}

function clicou4(){
    let mensagem = window.document.getElementById("mensagem");

    mensagem.innerHTML = `<p>
    Clicou no quarto botão.</p>`
}

function clicou5(){
    let mensagem = window.document.getElementById("mensagem");

    mensagem.innerHTML = ``
}