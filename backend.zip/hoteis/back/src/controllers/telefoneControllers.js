const db = require('../connect/db');

exports.createTelefone = (req, res) => {
    const { cliente_id, numero, tipo } = req.body;
    const query = 'INSERT INTO telefone (cliente_id, numero, tipo) VALUES (?, ?, ?)';
    db.query(query, [cliente_id, numero, tipo], (err, results) => {
        if (err) return res.status(500).send(err);
        res.status(201).json({ id: results.insertId });
    });
};

exports.getTelefones = (req, res) => {
    db.query('SELECT * FROM telefone', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
};

exports.getTelefoneById = (req, res) => {
    const query = 'SELECT * FROM telefone WHERE telefone_id = ?';
    db.query(query, [req.params.id], (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results[0]);
    });
};

exports.updateTelefone = (req, res) => {
    const { cliente_id, numero, tipo } = req.body;
    const query = 'UPDATE telefone SET cliente_id = ?, numero = ?, tipo = ? WHERE telefone_id = ?';
    db.query(query, [cliente_id, numero, tipo, req.params.id], (err) => {
        if (err) return res.status(500).send(err);
        res.sendStatus(204);
    });
};

exports.deleteTelefone = (req, res) => {
    const query = 'DELETE FROM telefone WHERE telefone_id = ?';
    db.query(query, [req.params.id], (err) => {
        if (err) return res.status(500).send(err);
        res.sendStatus(204);
    });
};