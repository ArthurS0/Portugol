// Back/SRC/Routes.js
const express = require('express');
const router = express.Router();
const connection = require('./connect/database');

// Rotas de exemplo
router.get('/alunos', (req, res) => {
    connection.query('SELECT * FROM Alunos', (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(results);
    });
});

router.get('/instrutores', (req, res) => {
    connection.query('SELECT * FROM Instrutores', (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(results);
    });
});

router.get('/aulas', (req, res) => {
    connection.query('SELECT * FROM Aulas', (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(results);
    });
});

module.exports = router;