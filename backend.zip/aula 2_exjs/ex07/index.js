function calcular(){
    let nome = window.prompt("Digitie o nome do aluno");
    let n1 = Number(window.prompt("Digite a primeira nota"));
    let n2 = Number(window.prompt("Digite a segunda nota"));
    let mensagem = window.document.getElementById("mensagem");

    mensagem.innerHTML = `<p>O aluno escolhido foi: <strong>${nome}</strong>.</p>
    <p>A primeira nota foi: ${n1}.</p>
    <p>A segunda nota foi: ${n2}.</p>
    <p>A média final foi: ${(n1+n2)/2}.</p>`


}