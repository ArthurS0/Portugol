const express = require('express')
const cors = require('cors')

//Configuração de saída para o front
const app = express();
app.use(express.json());
app.use(cors());

//Rota de teste da API
app.listen(3000, () => {
    console.log("Api rodando com sucesso!!")
})