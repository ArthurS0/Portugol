CREATE DATABASE biblioteca3;
USE biblioteca3;

CREATE TABLE livros(
    id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    titulo VARCHAR (252) NOT NULL,
    autor VARCHAR (252) NOT NULL,
    valor FLOAT NOT NULL
);