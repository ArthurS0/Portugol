function clicou(){
    let nome = window.prompt('Qual o seu nome');
    let mensagem = window.document.getElementById('mensagem');

    mensagem.innerHTML = `<p>Olá, <strong>${nome}</strong>! É
    um grande prazer te conhecer!</p>`


}