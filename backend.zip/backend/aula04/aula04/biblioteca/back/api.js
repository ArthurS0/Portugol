// Declarando as bibliotecas

const express = require("express");
const mysql = require("mysql");
const cors = require("cors");
const porta = 3000;
const bodyparser = require("body-parser");

//Conectar com o Banco de dados
const con = mysql.createConnection({
    user: 'root',
    host: 'localhost',
    database: 'biblioteca'
})

const create = (req, res) => {
    //Declarar os campos necessários
    let autorlivro = req.body.autorLivro;
    let descricaolivro = req.body.descricaolivro;

    //Conexão com o banco de dados
    let query = `INSERT INTO Livros (autorLivro, descricaoLivro) VALUE`
    query += `('${autorlivro}','${descricaolivro}');`;
    con.query(query, (err, result) => {
        if (err) {
            res.redirect("http://127.0.0.1:5500/biblioteca/front/index.html")
        } else {
            res.redirect("http://127.0.0.1:5500/biblioteca/front/index.html")
        }
    })


}

const read = (req, res) => {
    con.query("SELECT * FROM Livros", (err, result) => {
        if (err) {
            res.status(500).json(err)
        } else {
            res.json(result)
        }
    })
}

// Esse teste ira aparecer na pagina web!
const teste = (req, res) => {
    res.send("Api respondendo com sucesso!");
}

//Configuração de saída para o front-end/página
const app = express();
app.use(express.json());
app.use(cors());
app.use(bodyparser.urlencoded({ extended: true }))

//Rotas de saída
app.get("/", teste);
app.post("/livros", create);
app.get("/livros", read);

//Teste no console
app.listen(3000, () => {
    console.log("Servidor respondendo na porta: ", porta);
})