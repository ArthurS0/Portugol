function calcular(){
    var número  = window.prompt('Digite um valor');
    let mensagem = window.document.getElementById('mensagem');

    mensagem.innerHTML = `<p>O dobro de ${número} é ${número*2},
    e a metade é ${número/2}.</p>`


}