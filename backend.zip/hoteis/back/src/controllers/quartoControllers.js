const db = require('../connect/db');

exports.createQuarto = (req, res) => {
    const { numero, andar, tipo, valor_diaria, statusQuarto, cliente_id } = req.body;
    const query = 'INSERT INTO quartos (numero, andar, tipo, valor_diaria, statusQuarto, cliente_id) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(query, [numero, andar, tipo, valor_diaria, statusQuarto, cliente_id], (err, results) => {
        if (err) return res.status(500).send(err);
        res.status(201).json({ id: results.insertId });
    });
};

exports.getQuartos = (req, res) => {
    db.query('SELECT * FROM quartos', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
};

exports.getQuartoById = (req, res) => {
    const query = 'SELECT * FROM quartos WHERE quarto_id = ?';
    db.query(query, [req.params.id], (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results[0]);
    });
};

exports.updateQuarto = (req, res) => {
    const { numero, andar, tipo, valor_diaria, statusQuarto, cliente_id } = req.body;
    const query = 'UPDATE quartos SET numero = ?, andar = ?, tipo = ?, valor_diaria = ?, statusQuarto = ?, cliente_id = ? WHERE quarto_id = ?';
    db.query(query, [numero, andar, tipo, valor_diaria, statusQuarto, cliente_id, req.params.id], (err) => {
        if (err) return res.status(500).send(err);
        res.sendStatus(204);
    });
};

exports.deleteQuarto = (req, res) => {
    const query = 'DELETE FROM quartos WHERE quarto_id = ?';
    db.query(query, [req.params.id], (err) => {
        if (err) return res.status(500).send(err);
        res.sendStatus(204);
    });
};