function clicou(){
    window.alert("Você clicou no botão!");
}