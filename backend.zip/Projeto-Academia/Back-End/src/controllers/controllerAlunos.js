const con = require('../connect/banco').con;

const create = (req, res) => {

    let nome = req.body.nome;
    let cpf = req.body.cpf;
    let rg = req.body.rg;
    let telefone = req.body.telefone;
    let plano = req.body.plano;
    let endereco = req.body.endereco;
    let bairro = req.body.bairro;
    let cidade = req.body.cidade;

    // Conexão com o banco
    let query = `INSERT INTO aluno (nome, cpf, RG, telefone, plano, endereco, bairro, cidade) VALUES`
    query += `('${nome}', '${cpf}', '${rg}', '${telefone}', '${plano}', '${endereco}', '${bairro}', '${cidade}'); `;
    con.query(query, (err, result) => {
        if (err) {
            res.status(500).json(err)
        } else {
            res.status(201).json(result)
        }
    })
}

const read = (req, res) => {
    con.query('SELECT * FROM aluno', (err, result) => {
        if (err) {
            res.status(500).json(err)
        } else {
            res.json(result)
        }
    })
}

const deletar = (req, res)=> {
    let id = req.params.id;
    con.query(`DELETE FROM aluno WHERE alunoID = '${id}'`, (err, result) => {

        if(err){
            res.status(400).json(err).end();
    
        }else{
            res.status(201).json(result)
        }
    })
}

module.exports = {
    create,
    read,
    deletar,
}