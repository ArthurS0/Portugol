create database tarefas;
use tarefas;

create table cadastro(
    id int auto_increment primary key,
    titulo varchar(255) not null,
    descricao text,
    data_cadastro datetime default
    nome varchar(100       ) not null
)