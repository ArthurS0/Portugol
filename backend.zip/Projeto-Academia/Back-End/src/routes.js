const express = require('express');
const router = express.Router();

const aluno = require('./controllers/controllerAlunos')

const teste = (req, res) => {
    res.json("API funcionando com sucesso");
}

router.get('/', teste);
router.post('/aluno', aluno.create);
router.get('/aluno', aluno.read);
router.delete('/aluno/:id', aluno.deletar);
module.exports = router;