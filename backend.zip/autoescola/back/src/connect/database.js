// Back/SRC/Connect/database.js
const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Substitua com seu usuário do MySQL
    password: '', // Substitua com sua senha do MySQL
    database: 'autoescola'
});

connection.connect((err) => {
    if (err) {
        console.error('Erro ao conectar com o banco de dados:', err.stack);
        return;
    }
    console.log('Conectado ao banco de dados.');
});

module.exports = connection;