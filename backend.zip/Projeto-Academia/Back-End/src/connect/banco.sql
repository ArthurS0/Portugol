CREATE DATABASE ACADEMIA;
CREATE TABLE Equipamentos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    funcionando TINYINT NOT NULL
);

INSERT INTO Equipamentos (nome, descricao, funcionando) VALUES
('Esteira', 'Equipamento para corrida e caminhada.', 1),
('Bicicleta ergométrica', 'Bicicleta para exercícios aeróbicos.', 0),
('Supino', 'Equipamento para exercícios de peito.', 1);

SELECT * FROM Equipamentos WHERE funcionando = 1;

SELECT * FROM Equipamentos;